const ALLOWED_ROLES = new Set(['system', 'user', 'assistant']);
function jsonResponse(statusCode, body, allowedOrigin) {
    return {
        statusCode,
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': allowedOrigin,
            'Access-Control-Allow-Headers': 'Content-Type,Authorization',
            'Access-Control-Allow-Methods': 'POST,OPTIONS',
        },
        body: JSON.stringify(body),
    };
}
function sanitizeMessages(value) {
    if (!Array.isArray(value)) {
        throw new TypeError('messages debe ser un arreglo.');
    }
    const sanitized = value
        .filter((item) => item && typeof item === 'object')
        .map((item) => {
        const role = item.role;
        const content = item.content;
        if (typeof role !== 'string' || !ALLOWED_ROLES.has(role)) {
            throw new TypeError('Cada mensaje debe incluir un role válido.');
        }
        if (typeof content !== 'string' || !content.trim()) {
            throw new TypeError('Cada mensaje debe incluir content no vacío.');
        }
        return {
            role: role,
            content: content.trim(),
        };
    });
    if (!sanitized.length) {
        throw new TypeError('Debe enviarse al menos un mensaje.');
    }
    return sanitized;
}
function resolveAssistantText(payload) {
    if (payload.content?.trim())
        return payload.content.trim();
    if (payload.message?.trim())
        return payload.message.trim();
    if (payload.output_text?.trim())
        return payload.output_text.trim();
    const choiceText = payload.choices?.[0]?.message?.content?.trim();
    if (choiceText)
        return choiceText;
    throw new Error('El proveedor IA no devolvió contenido legible.');
}
export async function handler(event) {
    const allowedOrigin = process.env.ALLOWED_ORIGIN?.trim() || '*';
    const method = event.httpMethod ?? 'POST';
    if (method === 'OPTIONS') {
        return jsonResponse(204, {}, allowedOrigin);
    }
    if (method !== 'POST') {
        return jsonResponse(405, { error: 'Método no permitido.' }, allowedOrigin);
    }
    const apiUrl = process.env.AI_API_URL?.trim();
    const apiKey = process.env.AI_API_KEY?.trim() ?? '';
    const authHeader = process.env.AI_AUTH_HEADER?.trim() || 'Authorization';
    const defaultModel = process.env.AI_MODEL?.trim() ?? '';
    if (!apiUrl) {
        return jsonResponse(500, { error: 'Falta configurar AI_API_URL.' }, allowedOrigin);
    }
    try {
        const parsed = JSON.parse(event.body ?? '{}');
        const messages = sanitizeMessages(parsed.messages);
        const model = typeof parsed.model === 'string' && parsed.model.trim() ? parsed.model.trim() : defaultModel;
        const requestBody = {
            messages,
            ...(model ? { model } : {}),
        };
        const headers = {
            'Content-Type': 'application/json',
        };
        if (apiKey) {
            headers[authHeader] = apiKey.startsWith('Bearer ') ? apiKey : `Bearer ${apiKey}`;
        }
        const upstreamResponse = await fetch(apiUrl, {
            method: 'POST',
            headers,
            body: JSON.stringify(requestBody),
        });
        if (!upstreamResponse.ok) {
            return jsonResponse(upstreamResponse.status, { error: `El proveedor IA respondió con estado ${upstreamResponse.status}.` }, allowedOrigin);
        }
        const payload = (await upstreamResponse.json());
        const message = resolveAssistantText(payload);
        return jsonResponse(200, { message }, allowedOrigin);
    }
    catch (error) {
        const safeMessage = error instanceof Error ? error.message : 'Error inesperado del proxy.';
        return jsonResponse(400, { error: safeMessage }, allowedOrigin);
    }
}
